let frame = new Entity()
frame.addComponent(new GLTFShape("models/Alexandria.glb"))
frame.addComponent(new Transform({
            rotation: Quaternion.Euler(0, 0, 0),
            position: new Vector3(8 , 0, 0),
            scale: new Vector3(1, 1, 1)
        }))
engine.addEntity(frame)

let openIndexLogo = new Entity()
openIndexLogo.addComponent(new GLTFShape("models/OpenIndex.glb"))
/*openIndexLogo.addComponent(new Transform({
            rotation: Quaternion.Euler(0, -90, 0),
            position: new Vector3(1.8 , 20, -6),
            scale: new Vector3(4, 4, 4)
        }))*/
openIndexLogo.addComponent(new Transform({
            rotation: Quaternion.Euler(0, 180, 0),
            position: new Vector3(-42, 4, 9.5),
            scale: new Vector3(1.5, 1.5, 1.5)
        }))
engine.addEntity(openIndexLogo)

let alexandriaLogo = new Entity()
alexandriaLogo.addComponent(new GLTFShape("models/AlexandriaLogo.glb"))
alexandriaLogo.addComponent(new Transform({
            rotation: Quaternion.Euler(0, 180, 0),
            position: new Vector3(-12, 7, 13.4),
            scale: new Vector3(3, 3, 3)
        }))
engine.addEntity(alexandriaLogo)

const elevatorShape = new GLTFShape("models/Elevator.glb")
let elevator01 = new Entity()
elevator01.addComponent(elevatorShape)
elevator01.addComponent(new Transform({
            rotation: Quaternion.Euler(0, 180, 0),
            position: new Vector3(8-0.19, 0.1, -5.39),
            scale: new Vector3(1, 1, 1)
        }))
engine.addEntity(elevator01)

let elevator02 = new Entity()
elevator02.addComponent(elevatorShape)
elevator02.addComponent(new Transform({
            rotation: Quaternion.Euler(0, 180, 0),
            position: new Vector3(8-46.28, 0.15, -1.88),
            scale: new Vector3(1, 1, 1)
        }))
engine.addEntity(elevator02)

const elevatorButtonsShape = new GLTFShape("models/ElevatorButtons.glb")
let elevator01_array = []
let elevator02_array = []
for (let i = 0; i < 9; i++) {
    elevator01_array.push(new Entity())
    elevator01_array[elevator01_array.length-1].addComponent(elevatorButtonsShape)
    elevator01_array[elevator01_array.length-1].addComponent(new Transform({
                rotation: Quaternion.Euler(0, 180, 0),
                position: new Vector3(7-0.25, 1.5+(i*8.02), -5.39),
                scale: new Vector3(1, 1, 1)
            }))
    engine.addEntity(elevator01_array[elevator01_array.length-1])
    //
    elevator02_array.push(new Entity())
    elevator02_array[elevator02_array.length-1].addComponent(elevatorButtonsShape)
    elevator02_array[elevator02_array.length-1].addComponent(new Transform({
                rotation: Quaternion.Euler(0, 180, 0),
                position: new Vector3(7-46.27, 1.5+(i*8.02), -1.88),
                scale: new Vector3(1, 1, 1)
            }))
    engine.addEntity(elevator02_array[elevator02_array.length-1])
}

const buttonShape = new BoxShape()
const buttonMaterial = new Material()
buttonMaterial.albedoColor = Color3.Yellow()
buttonMaterial.metallic = 1.0
buttonMaterial.roughness = 0.7

let elevator01_buttons_array = []
let elevator02_buttons_array = []
for (let i = 0; i < 9; i++) {
    for (let ii = 0; ii < 9; ii++) {
        elevator01_buttons_array.push(new Entity())
        elevator01_buttons_array[elevator01_buttons_array.length-1].addComponent(buttonShape)
        elevator01_buttons_array[elevator01_buttons_array.length-1].addComponent(buttonMaterial)
        elevator01_buttons_array[elevator01_buttons_array.length-1].setParent(elevator01_array[i])
        elevator01_buttons_array[elevator01_buttons_array.length-1].addComponent(new Transform({
                    rotation: Quaternion.Euler(0, 50, 0),
                    position: new Vector3(-0.03, -0.922+(ii*0.2322), 0.65),
                    scale: new Vector3(0.1, 0.1, 0.025)
                }))
        elevator01_buttons_array[elevator01_buttons_array.length-1].addComponent(
            new OnPointerDown((e) => {moveElevator(e, ii)}, {hoverText: "Goto floor "+ii, distance: 2})
        )
        //
        elevator02_buttons_array.push(new Entity())
        elevator02_buttons_array[elevator02_buttons_array.length-1].addComponent(buttonShape)
        elevator02_buttons_array[elevator02_buttons_array.length-1].addComponent(buttonMaterial)
        elevator02_buttons_array[elevator02_buttons_array.length-1].setParent(elevator02_array[i])
        elevator02_buttons_array[elevator02_buttons_array.length-1].addComponent(new Transform({
                    rotation: Quaternion.Euler(0, 50, 0),
                    position: new Vector3(-0.03, -0.922+(ii*0.2322), 0.65),
                    scale: new Vector3(0.1, 0.1, 0.025)
                }))
        elevator02_buttons_array[elevator02_buttons_array.length-1].addComponent(
            new OnPointerDown((e) => {moveElevator(e, ii)}, {hoverText: "Goto floor "+ii, distance: 2})
        )
    }
}

let moving = false
let level_to = 0
let current_level = 0

function moveElevator(e, level) {
    if (moving == true) {
        return
    }
    if (level == current_level) {
        return
    }
    level_to = level
    moving = true
}


export class SimpleMove implements ISystem {
    update() {
        if (moving == false) {
            return
        }
        let transform = elevator01.getComponent(Transform)

        if (level_to > current_level && transform.position.y > level_to * 8.02) {
            moving = false
            current_level = level_to
        }
        if (level_to < current_level && transform.position.y < level_to * 8.02) {
            moving = false
            current_level = level_to
        }

        let distance
        if (level_to > current_level) {
            distance = Vector3.Up().scale(0.1)
        } else if (level_to < current_level) {
            distance = Vector3.Down().scale(0.1)
        }
        transform.translate(distance)
        let transform02 = elevator02.getComponent(Transform)
        transform02.position.y = transform.position.y
    }
}

engine.addSystem(new SimpleMove())


const text = "The Open Index Protocol uses blockchain technology\nand distributed networking to operate with no central authority.\nIt is an open source specification for a persistent\nworldwide index and file library useful for data publishing,\nfile distribution and facilitating direct payments.\nFind developer's resources at https://www.openindexprotocol.com"

const text_front = new Entity()
const textFrontShape = new TextShape(text)
//textFrontShape.color = new Color3(0.8, 0.6, 0.3)
textFrontShape.color = new Color3(0.2, 0.12, 0.1)
textFrontShape.fontSize = 2
textFrontShape.outlineColor = new Color3(0.5, 0.4, 0.1)
textFrontShape.outlineWidth = 0.15
text_front.addComponent(textFrontShape)

text_front.addComponent(new Transform({
    position: new Vector3(-45-2, 1.5, 8.6-0.7),
    rotation: Quaternion.Euler(0, -23, 0)
}))
engine.addEntity(text_front)

const textLinkEntity = new Entity()
textLinkEntity.addComponent(new BoxShape())
textLinkEntity.addComponent(new Transform({
    scale: new Vector3(-12*0.5, -3*0.5, -0.01*0.5),
    position: new Vector3(-45-2, 1.5, 8.6-0.7),
    rotation: Quaternion.Euler(0, -23, 0)
}))
textLinkEntity.addComponent(  new OnPointerDown(() => {
    openExternalURL('https://www.openindexprotocol.com')
},
    {
      button: ActionButton.ANY,
      showFeedback: true,
      hoverText: "Go to openindexprotocol.com",
    }))
const linkMaterial = new Material()
linkMaterial.albedoColor = new Color4(0, 0, 0, 0)
textLinkEntity.addComponent(linkMaterial)
engine.addEntity(textLinkEntity)

//

const myVideoClip = new VideoClip("materials/Alexandria.mp4")
const pauseTexture = new Texture("materials/Alexandria.png")
const myVideoTexture = new VideoTexture(myVideoClip)
const screenMaterial = new BasicMaterial()
screenMaterial.texture = pauseTexture

const screen = new Entity()
screen.addComponent(new BoxShape())
screen.addComponent(
    new Transform({
        scale: new Vector3(-10*0.5, -6*0.5, -0.01*0.5),
        position: new Vector3(-45-2, 4, 8.6-0.7),
        rotation: Quaternion.Euler(0, 180-23, 0),
    })
)
screen.addComponent(screenMaterial)
screen.addComponent(
  new OnPointerDown(() => {
    screenMaterial.texture = myVideoTexture
    myVideoTexture.playing = !myVideoTexture.playing
  },
      {
        button: ActionButton.ANY,
        showFeedback: true,
        hoverText: "Play / Pause Video",
      })
)
engine.addEntity(screen)

/*
let elevator01_buttons = new Entity()
let elevator01_buttons_base = new Entity()
elevator01_buttons_base.addComponent(new BoxShape())
elevator01_buttons_base.setParent(elevator01_buttons)
elevator01_buttons_base.addComponent(new Transform({
            rotation: Quaternion.Euler(0, 0, 0),
            position: new Vector3(3, 2, 3),
            scale: new Vector3(0.5, 1, 0.3)
        }))

engine.addEntity(elevator01_buttons)*/
